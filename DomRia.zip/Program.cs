using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DomRia.Product;
using DomRia.Product.Users;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace DomRia
{
    public class Program
    {
        public static void Main(string[] args)
        {
            MainMenu menu = new MainMenu();
            menu.Menu();
        }
    }
}