﻿using System;
using DomRia.Product.Info;

namespace DomRia.Product
{
    public class Product
    {
        public int ID { get; set; }
        public string Title { get; set; }
        public Price price;
        public GEO geo;
        public Contact contact;
        public HomeSize size;
        public string Text { get; set; }

        public Product()
        {
            Title = String.Empty;
            Text = String.Empty;
            price = null;
            geo = null;
            contact = null;
            size = null;
        }

        public Product(string title, string text)
        {
            ID = 0;
            Title = title;
            Text = text;
        }

        public override string ToString()
        {
            return String.Format("ID: {0}\nЗаголовок: {1}\nКвадратура общая: {2}\nКвадратура жилая: {3}\nКвадратура кухни: {4}\nГород: {5}\nУлица: {6}\nНомер дома: {7}\nЭтаж: {8}\n" +
                                 "ФИО: {9}\nНомер телефона: {10}\nСтоимость в $: {11}\nСтоимость в гривне: {12}\nОписание: {13}\n",ID,Title,size.TotalPlace,size.DwellingPlace,size.Kithchen,
                geo.City,geo.Street,geo.NumberHause,geo.Floor,contact.FIO,contact.Tel,price.PriceUSD,price.PriceUA,Title);
        }

        public void ShowInfoHome()
        {
            Console.WriteLine(String.Format("ID: {0}\nЗаголовок: {1}\nКвадратура общая: {2}\nКвадратура жилая: {3}\nКвадратура кухни: {4}\nГород: {5}\nУлица: {6}\nНомер дома: {7}\nЭтаж: {8}\n" +
                                            "ФИО: {9}\nНомер телефона: {10}\nСтоимость в $: {11}\nСтоимость в гривне: {12}\nОписание: {13}\n",ID,Title,size.TotalPlace,size.DwellingPlace,size.Kithchen,
                geo.City,geo.Street,geo.NumberHause,geo.Floor,contact.FIO,contact.Tel,price.PriceUSD,price.PriceUA,Title));
        }
       
    }
}