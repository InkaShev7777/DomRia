﻿using System;
using System.Threading;
using DomRia.Product.Users;

namespace DomRia.Product
{
    public class MainMenu
    {
        private Manager manager;
        private Buyer buyer;

        public MainMenu()
        {
            manager = new Manager();
            buyer = new Buyer();
        }
        public void Menu()
        {
            int ch;
            do
            {
                Console.Clear();
                Console.WriteLine("\tМеню");
                Console.WriteLine("1 - Если вы риелтор");
                Console.WriteLine("2 - Если вы клиент");
                Console.WriteLine("0 - Выход");
                Console.Write("Ваш выбор: ");
                ch = int.Parse(Console.ReadLine());
                if(ch == 0) break;
                switch (ch)
                {
                    case 1:
                        Console.Clear();
                        MenuManager();
                        Console.Clear();
                        break;
                    case 2:
                        Console.Clear();
                        MenuBuyer();
                        Console.Clear();
                        break;
                    default:
                        Console.WriteLine("Не верный пункт-меню!!!");
                        Thread.Sleep(1000);
                        Console.Clear();
                        break;
                }
            } while (ch != 0);
        }

        private void MenuManager()
        {
            int ch;
            do
            {
                Console.Clear();
                Console.WriteLine("\tМеню");
                Console.WriteLine("1 - Добавить объявление");
                Console.WriteLine("2 - Вывод списка всех квартир");
                Console.WriteLine("3 - Удаление Объявления");
                Console.WriteLine("0 - Выход");
                Console.Write("Сделайте свой выбо:");
                ch = int.Parse(Console.ReadLine());
                if(ch == 0) break;
                switch (ch)
                {
                    case 1:
                        Console.Clear();
                        manager.AddInFile();
                        Console.Clear();
                        break;
                    case 2:
                        Console.Clear();
                        manager.Show();
                        Thread.Sleep(5000);
                        Console.Clear();
                        break;
                    case 3:
                        Console.Clear();
                        manager.DelAnnouncement();
                        Thread.Sleep(5000);
                        Console.Clear();
                        break;
                    default:
                        Console.Clear();
                        Console.WriteLine("Не верный пункт-меню!!!");
                        Thread.Sleep(1000);
                        Console.Clear();
                        break;
                }
            } while (ch != 0);
        }

        private void MenuBuyer()
        {
            int ch;
            do
            {
                Console.Clear();
                Console.WriteLine("\tМеню");
                Console.WriteLine("1 - Вывод списка объявлений");
                Console.WriteLine("2 - Поиск объявления");
                Console.WriteLine("3 - Сортировка объявлений по цене(от дорогих к дешевым)");
                Console.WriteLine("4 - Сортировка объявлений по цене(от дешевых к дорогим)");
                Console.WriteLine("5 - Поиск по городу");
                Console.WriteLine("6 - Поиск по цене");
                Console.WriteLine("7 - Поиск по количеству комнат");
                Console.WriteLine("0 - Выход");
                Console.Write("Ваш выбор: ");
                ch = int.Parse(Console.ReadLine());
                if(ch == 0) break;
                switch (ch)
                {
                    case 1:
                        Console.Clear();
                        buyer.Show();
                        Thread.Sleep(5000);
                        Console.Clear();
                        break;
                    case 2:
                        Console.Clear();
                        buyer.FindAd();
                        Thread.Sleep(5000);
                        Console.Clear();
                        break;
                    case 3:
                        Console.Clear();
                        buyer.SortAscending();
                        Thread.Sleep(5000);
                        Console.Clear();
                        break;
                    case 4:
                        Console.Clear();
                        buyer.SortDescending();
                        Thread.Sleep(5000);
                        Console.Clear();
                        break;
                    case 5:
                        Console.Clear();
                        buyer.CitySearch();
                        Thread.Sleep(5000);
                        Console.Clear();
                        break;
                    case 6:
                        Console.Clear();
                        buyer.PriceSearch();
                        Thread.Sleep(5000);
                        Console.Clear();
                        break;
                    case 7:
                        Console.Clear();
                        buyer.sizeSearch();
                        Thread.Sleep(5000);
                        Console.Clear();
                        break;
                }
            } while (ch != 0);
            
        }
    }
}