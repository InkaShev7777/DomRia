﻿namespace DomRia.Product.Info
{
    public class Price
    {
        public long PriceUSD { get; set; }
        public double PriceUA { get; set; }

        public Price()
        {
            PriceUA = -1;
            PriceUSD = -1;
        }
        public Price(long priceUsd, double priceUa)
        {
            PriceUSD = priceUsd;
            PriceUA = priceUa;
        }
    }
}