﻿using System;

namespace DomRia.Product.Info
{
    public class GEO
    {
        public string City { get; set; }
        public string Street { get; set; }
        public int NumberHause { get; set; }
        public int Floor { get; set; }

        public GEO()
        {
            City = String.Empty;
            Street = String.Empty;
            NumberHause = -1;
            Floor = -1;
        }

        public GEO(string city, string street, int numberHause, int floor)
        {
            City = city;
            Street = street;
            NumberHause = numberHause;
            Floor = floor;
        }
    }
}