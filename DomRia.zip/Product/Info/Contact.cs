﻿using System;

namespace DomRia.Product.Info
{
    public class Contact
    {
        public string FIO { get; set; }
        public string Tel { get; set; }

        public Contact()
        {
            FIO = string.Empty;
            Tel = String.Empty;
        }

        public Contact(string fio, string tel)
        {
            FIO = fio;
            Tel = tel;
        }
    }
}