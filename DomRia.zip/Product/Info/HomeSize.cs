﻿namespace DomRia.Product.Info
{
    public class HomeSize
    {
        public double TotalPlace { get; set; }
        public double DwellingPlace { get; set; }
        public double Kithchen { get; set; }

        public HomeSize()
        {
            TotalPlace = -1;
            DwellingPlace = -1;
            Kithchen = -1;
        }

        public HomeSize(double totalPlace, double dwellingPlace, double kithchen)
        {
            TotalPlace = totalPlace;
            DwellingPlace = dwellingPlace;
            Kithchen = kithchen;
        }
    }
}