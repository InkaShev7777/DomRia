﻿using System;
using System.Collections.Generic;
using System.IO;
using DomRia.Product.Info;

namespace DomRia.Product.Users
{
    public class Manager
    {
        private List<Product> Products = null;
        public Product home;
        public Manager()
        {
            Products = new List<Product>();
            home = new Product();
        }
        public void Add()
        {
            Console.WriteLine("Введите заголовок объявления: ");
            home.Title = Console.ReadLine();
            Console.Clear();
            
            Console.WriteLine("Введите общую кубатуру объекта: ");
            double totalPlace = double.Parse(Console.ReadLine());
            Console.WriteLine("Введите жилую площадь: ");
            double dwellingPlace  = double.Parse(Console.ReadLine());
            Console.WriteLine("Введите квадратуру кухни: ");
            double kithchen = double.Parse(Console.ReadLine());
            Console.Clear();
            home.size = new HomeSize(totalPlace,dwellingPlace,kithchen);
            
            Console.WriteLine("Введите город: ");
            string city = Console.ReadLine();
            Console.WriteLine("Введите улицу: ");
            string street = Console.ReadLine();
            Console.WriteLine("Введите номер дома: ");
            int numberHause = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите этаж: ");
            int floor = int.Parse(Console.ReadLine());
            home.geo = new GEO(city, street,numberHause,floor);
            
            Console.Clear();
            Console.WriteLine("Введите ФИО: ");
            string fio = Console.ReadLine();
            Console.Write("Введите номер телефона: +380");
            string tel = Console.ReadLine();
            home.contact = new Contact(fio,tel);
            Console.Clear();

            Console.WriteLine("Введите стоимость объекта в $: ");
            long usd = long.Parse(Console.ReadLine());
            double ua = usd * 29.90;
            home.price = new Price(usd, ua);
            Console.Clear();

            Console.WriteLine("Введите описание вашего объявления: ");
            string text = Console.ReadLine();
            home.Text = text;
            
            Products.Add(home);
        }

        public void ShowListHome()
        {
            foreach (var i in Products)
            {
                i.ShowInfoHome();
            }
        }

        public void WriteInFile()
        {
            foreach (var i in Products)
            {
                File.AppendAllText("DomRia.txt",i.ToString());
            }
        }
    }
}