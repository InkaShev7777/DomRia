﻿using System;
using System.Collections.Generic;
using System.IO;
using DomRia.Product.Info;

namespace DomRia.Product.Users
{
    public class Manager:PerentClass
    {
        public Manager()
        {
            Products = new List<Product>();
            _product = new Product();
            ReadFile();
        }
        public void AddInFile()
        {
            _product = new Product();
            if (Products.Count > 0)
            {
                _product.ID = Products[Products.Count - 1].ID;
                _product.ID++;
            }
            else
            {
                _product.ID = 0;
            }
            Console.WriteLine("Введите заголовок объявления: ");
            _product.Title = Console.ReadLine();
            Console.Clear();
            
            Console.WriteLine("Введите общую кубатуру объекта: ");
            double totalPlace = double.Parse(Console.ReadLine());
            Console.WriteLine("Введите жилую площадь: ");
            double dwellingPlace  = double.Parse(Console.ReadLine());
            Console.WriteLine("Введите квадратуру кухни: ");
            double kithchen = double.Parse(Console.ReadLine());
            Console.Clear();
            _product.size = new HomeSize(totalPlace,dwellingPlace,kithchen);
            
            Console.WriteLine("Введите город: ");
            string city = Console.ReadLine();
            Console.WriteLine("Введите улицу: ");
            string street = Console.ReadLine();
            Console.WriteLine("Введите номер дома: ");
            int numberHause = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите этаж: ");
            int floor = int.Parse(Console.ReadLine());
            _product.geo = new GEO(city, street,numberHause,floor);
            
            Console.Clear();
            Console.WriteLine("Введите ФИО: ");
            string fio = Console.ReadLine();
            Console.Write("Введите номер телефона: +380");
            string tel = Console.ReadLine();
            _product.contact = new Contact(fio,tel);
            Console.Clear();

            Console.WriteLine("Введите стоимость объекта в $: ");
            long usd = long.Parse(Console.ReadLine());
            double ua = usd * 29.90;
            _product.price = new Price(usd, ua);
            Console.Clear();

            Console.WriteLine("Введите описание вашего объявления: ");
            string text = Console.ReadLine();
            _product.Text = text;
            Products.Add(_product);
            WriteInFile();
        }

        public override void Show()
        {
            if (Products.Count > 0)
            {
                foreach (var i in Products)
                {
                    i.ShowInfoHome();
                }
            }
            else
            {
                Console.WriteLine("Файл пуст");
            }
            
        }

        public void WriteInFile()
        {
            File.Delete("DomRia.txt");
            foreach (var i in Products)
            {
                File.AppendAllText("DomRia.txt",i.ToString());
            }
        }

        public void DelAnnouncement()
        {
            if (File.Exists("DomRia.txt"))
            {
                ReadFile();
                Console.Write("Введите ID объявления которое необходимо удалить: ");
                int id = int.Parse(Console.ReadLine());
                for (int i = 0; i < Products.Count - 1; i++)
                {
                    if (Products[i].ID.Equals(id))
                    {
                        Products.Remove(Products[i]);
                    }
                }
            }
            else
            {
                Console.WriteLine("Список пуст");
            }
            

        }
    }
}