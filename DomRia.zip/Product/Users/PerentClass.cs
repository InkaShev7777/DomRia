﻿using System;
using System.Collections.Generic;
using System.IO;
using DomRia.Product.Info;

namespace DomRia.Product.Users
{
    public abstract class PerentClass
    {
        protected List<Product> Products = null;
        public Product _product;

        public PerentClass()
        {
            Products = new List<Product>();
            _product = new Product();
        }

        public void ReadFile()
        {
            if (File.Exists("DomRia.txt"))
            {
                string info = File.ReadAllText("DomRia.txt");
                string[] information = info.Split(':', '\n');
                for (int i = 0; i < information.Length - 1; i++)
                {
                    _product = new Product();
                    _product.size = new HomeSize();
                    _product.geo = new GEO();
                    _product.contact = new Contact();
                    _product.price = new Price();

                    _product.ID = int.Parse(information[i + 1]);
                    _product.Title = information[i + 3].TrimStart();
                    _product.size.TotalPlace = double.Parse(information[i + 5].TrimStart());
                    _product.size.DwellingPlace = double.Parse(information[i + 7].TrimStart());
                    _product.size.Kithchen = double.Parse(information[i + 9].TrimStart());
                    _product.geo.City = information[i + 11].TrimStart();
                    _product.geo.Street = information[i + 13].TrimStart();
                    _product.geo.NumberHause = int.Parse(information[i + 15].TrimStart());
                    _product.geo.Floor = int.Parse(information[i + 17].TrimStart());
                    _product.contact.FIO = information[i + 19].TrimStart();
                    _product.contact.Tel = "+380" + information[i + 21].TrimStart();
                    _product.price.PriceUSD = long.Parse(information[i + 23].TrimStart());
                    _product.price.PriceUA = double.Parse(information[i + 25].TrimStart());
                    _product.Text = information[i + 27].TrimStart();
                    Products.Add(_product);
                    i += 27;
                }
            }
            // else
            // {
            //     Console.WriteLine("Файл не существует!!!");
            // }
            
        }
        public abstract void Show();
    }
}