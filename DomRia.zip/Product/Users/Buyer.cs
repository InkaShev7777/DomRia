﻿namespace DomRia.Product.Users
{
    public class Buyer
    {
        
    }
}