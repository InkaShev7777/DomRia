﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using DomRia.Product.Info;

namespace DomRia.Product.Users
{
    public class Buyer:PerentClass
    {
        public Buyer()
        {
            Products = new List<Product>();
            ReadFile();
        }
        public override void Show()
        {
            foreach (var i in Products)
            {
                i.ShowInfoHome();
            }
        }

        public void FindAd()
        {
            if (File.Exists("DomRia.txt"))
            {
                Console.Write("Введите ID объявления:");
                int id = int.Parse(Console.ReadLine());
                if (Products.Count >= id)
                {
                    for (int i = 0; i < Products.Count; i++)
                    {
                        if (Products[i].ID.Equals(id))
                        {
                            Console.WriteLine(Products[i].ToString());
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Объявления с таким ID Нет!!!");
                }
            }
            else
            {
                Console.WriteLine("Список пуст");
            }
        }

        public void CitySearch()
        {
            if (File.Exists("DomRia.txt"))
            {
                Console.Write("Введите необходимый город:");
                string fCity = Console.ReadLine();
                
                    for (int i = 0; i < Products.Count; i++)
                    {
                        if (Products[i].geo.City.Equals(fCity))
                        {
                            Console.WriteLine(Products[i].ToString());
                        }
                    }
            }
            else
            {
                Console.WriteLine("Список пуст");
            }
        }

        public void PriceSearch()
        {
            if (File.Exists("DomRia.txt"))
            {
                Console.Write("Введите ценовой диапазон ОТ: ");
                long startPrice = long.Parse(Console.ReadLine());
                Console.Write("Введите ценовой диапазон ДО: ");
                long endPrice = long.Parse(Console.ReadLine());
                List<Product> rezSearch = new List<Product>();
                for (int i = 0; i < Products.Count; i++)
                {
                    rezSearch = Products.FindAll(x => x.price.PriceUSD >= startPrice && x.price.PriceUSD <= endPrice);
                }

                foreach (var i in rezSearch)
                {
                    Console.WriteLine(i.ToString());
                }
            }
            else
            {
                Console.WriteLine("Список пуст");
            }
        }

        public void sizeSearch()
        {
            if (File.Exists("DomRia.txt"))
            {
                Console.Write("Введите необходимую квадратуру: ");
                int size = int.Parse(Console.ReadLine());
                List<Product> rezSearch = new List<Product>();
                for (int i = 0; i < Products.Count; i++)
                {
                    rezSearch = Products.FindAll(x => x.size.TotalPlace == size);
                }
                foreach (var i in rezSearch)
                {
                    Console.WriteLine(i.ToString());
                }
            }
            else
            {
                Console.WriteLine("Список пуст");
            }
        }

        public void SortAscending()
        {
            if (File.Exists("DomRia.txt"))
            {
                var rez = Products.OrderBy(n => n.price.PriceUSD);
                foreach (var i in rez)
                {
                    Console.WriteLine(i.ToString());
                }
            }
            else
            {
                Console.WriteLine("Список пуст");
            }
        }
        public void SortDescending()
        {
            if (File.Exists("DomRia.txt"))
            {
                var rez = Products.OrderByDescending(n => n.price.PriceUSD);
                foreach (var i in rez)
                {
                    Console.WriteLine(i.ToString());
                }
            }
            else
            {
                Console.WriteLine("Список пуст");
            }
        }
    }
}