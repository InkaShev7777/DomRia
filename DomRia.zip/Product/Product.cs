﻿using System;
using DomRia.Product.Info;

namespace DomRia.Product
{
    public class Product
    {
        public string Title { get; set; }
        public Price price;
        public GEO geo;
        public Contact contact;
        public HomeSize size;
        public string Text { get; set; }

        public Product()
        {
            Title = String.Empty;
            Text = String.Empty;
            price = null;
            geo = null;
            contact = null;
            size = null;
        }

        public Product(string title, string text)
        {
            Title = title;
            Text = text;
        }

        public override string ToString()
        {
            return String.Format("Заголовок: {0} Квадратура общая: {1} Квадратура жилая: {2} Квадратура кухни: {3} Город: {4} Улица: {5} Номер дома: {6} Этаж: {7} " +
                                 "ФИО: {8} Номер телефона: {9} Стоимость в $: {10} Стоимость в гривне: {11} Описание: {12}",Title,size.TotalPlace,size.DwellingPlace,size.Kithchen,
                geo.City,geo.Street,geo.NumberHause,geo.Floor,contact.FIO,contact.Tel,price.PriceUSD,price.PriceUA,Title);
                                 
        }

        public void ShowInfoHome()
        {
            Console.WriteLine(String.Format("Заголовок: {0} \nКвадратура общая: {1} Квадратура жилая: {2} Квадратура кухни: {3} \nГород: {4} Улица: {5} Номер дома: {6} Этаж: {7} \n" +
                                            "ФИО: {8} Номер телефона: +380{9} \nСтоимость в $: {10} Стоимость в гривне: {11} \nОписание: {12}",Title,size.TotalPlace,size.DwellingPlace,size.Kithchen,
                geo.City,geo.Street,geo.NumberHause,geo.Floor,contact.FIO,contact.Tel,price.PriceUSD,price.PriceUA,Title));
        }
    }
}